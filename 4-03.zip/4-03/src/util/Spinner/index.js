import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

const style = {
	marginLeft: "40%",
	marginTop: "15%"
}
const MainApp = () => (
		<CircularProgress style={style} className="progress-primary" size={60} mode="determinate" value={75} /> 
);

export default MainApp;