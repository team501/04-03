/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import axios from 'axios';

import MUIDataTable from "mui-datatables";

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

// import Base URL from Config
import {baseURL} from '../../../services/Config';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';


//Bootstrap datatable custom cell style
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import cellEditFactory from 'react-bootstrap-table2-editor';


import {graphQlURLPrd} from '../../../services/Config.js';


import TableConfig from  "JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/chuteTableConfig/chuteTableJson.json"
import Spinner from 'Util/Spinner';


export default class chuteStatus extends Component {

    state = {  
        data: [],
        isLoading:true
     };



    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
    }
    
		//Fetch Sorter ID from URL params
		sorterID  = this.props.match.params.sorterID;
		
    // on reload fetch new data from data base
		onReload = () => {
		/// using graphql

		let query = TableConfig.container.leftSegment.components[0].options.query;

		let startTime = 201903231431;//dateFormat(new Date(), "yyyymmddHHMM");
		let sorterId = this.sorterID;

		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, sorterId }
			})
		})
		.then(r => r.json())
		.then(data => { 
			
			this.setState({ 
				data: data.data.getChuteDetails,
				isLoading:false
			});
		    
		})
		.catch((error) => {
			console.log(error);
			this.setState({ data: [],
						    isLoading:false
						 }); 
		});
    }

    render() {
	
		//from json
		let recordsPerPage = TableConfig.container.leftSegment.components[0].options.recordsPerPage;

        const { SearchBar } = Search;
        
		//Bootstrap datatable custom cell style
		const headerSortingStyle = { backgroundColor: '#c8e6c9' };
					
		//Set Caret icon for sorting directions
		const sortCaret = (order, column) => {
			if (!order) return (<span class="order">&nbsp;&nbsp;<span class="dropdown"><span class="icon-arrow-up"></span></span><span class="dropup"><span class="icon-arrow-down"></span></span></span>);
			else if (order === 'asc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-up"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
			else if (order === 'desc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-down"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
			return null;
		};
		
		const columns = [			
			{
				dataField: 'chuteId',
				text: <IntlMessages id="chuteStatusTable.Chute No." />,
				sort: true,
				sortCaret,
				headerSortingStyle
			},
			{
				dataField: 'full',
				text: <IntlMessages id="chuteStatusTable.Full" />,
				sort: true,
				sortCaret,
				headerSortingStyle
			},
			{
				dataField: 'disabled',
				text: <IntlMessages id="chuteStatusTable.Disabled" />,
				sort: true,
				sortCaret,
				headerSortingStyle
			},
			{														
				dataField: 'duration',
				text: <IntlMessages id="chuteStatusTable.Duration" />,
				sort: true,
				sortCaret,
				headerSortingStyle				
			},
			{
				dataField: 'statusTs',
				text: <IntlMessages id="chuteStatusTable.Timestamp" />,
				sort: true,
				sortCaret,
				headerSortingStyle
			}
		];
		//Custom search results information
		const customTotal = (from, to, size) => (
			<span className="react-bootstrap-table-pagination-total">
				<IntlMessages id="Table.Pagination.Showing" /> { from } <IntlMessages id="Table.Pagination.to" /> { to } <IntlMessages id="Table.Pagination.of" /> { size } <IntlMessages id="Table.Pagination.Results" />
			</span>
		);
	
		//Defininf options for pagination
		const options = {
			paginationSize: 4,
			pageStartIndex: 1,
			alwaysShowAllBtns: true, // Always show next and previous button
			withFirstAndLast: true, // Hide the going to First and Last page button
			hideSizePerPage: true, // Hide the sizePerPage dropdown always
			showTotal: true,
			hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
			paginationTotalRenderer: customTotal,
			sizePerPageList: [
				{
					text: recordsPerPage, value: recordsPerPage //number of results per page
				}
			] // A numeric array is also available. the purpose of above example is custom the text
		};
		
		//Custom Reload button for data rerendering
		const ReloadButton = () => {
			return (
			  <div>
				<button className="btn pull-right" onClick={() => {this.setState({isLoading: true}); this.onReload()}}>
					<span aria-hidden="true" class="icon-refresh"></span>
				</button>
			  </div>
			);
		  };

	if(this.state.isLoading){
		return (	
	<div className="data-table-wrapper">
				 <PageTitleBar 
                    title={<IntlMessages id="chuteStatusTable.title" />} 
					match={this.props.match} 
                    url={`/app/dashboard/sorterDetails/${this.sorterID}`}
		      subTitle={" " +`${this.sorterID}`} 
                />

			 <RctCard>
		        <RctCardContent>
				<Spinner />
			</RctCardContent>
			</RctCard ></div>);
		} else {


        return (
            <div className="data-table-wrapper chute-status-height">
                <PageTitleBar 
                    title={<IntlMessages id="chuteStatusTable.title" />}  
					match={this.props.match} 
                    url={`/app/dashboard/sorterDetails/${this.sorterID}`}
		      subTitle={" " +`${this.sorterID}`} 
                />
                {/* Card To hold Table */}
                <RctCard>
		            <RctCardContent>
                                        					
						<ToolkitProvider
						keyField={Math.floor((Math.random() * 10000000) + 1)} //Generate unique rendom number between 0 to 10000000 for row key
						data={ this.state.data } //Input data
						columns={ columns }
						search 
						>
						{
							props => (
							<div>
								<ReloadButton { ...props.searchProps } />
								<SearchBar
								{ ...props.searchProps }
								className="custome-search-field"
								style={ { color: 'black' } }
								delay={ 1000 }
								placeholder="Search"
								/>
								<BootstrapTable
								{ ...props.baseProps }
								bordered={ false }
								striped
								hover
								condensed
								pagination={ paginationFactory(options) }
								/>
							</div>
							)
						}
					</ToolkitProvider>
                    </RctCardContent>
			    </RctCard >
            </div>
        );}
    }
}


