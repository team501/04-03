import React, { Component } from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import "react-tabs/style/react-tabs.css";


class ConfigClass extends Component {
    constructor() {
      super();
      this.state = { tabIndex: 0 };
    }
    render() {
      return (
        <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })}>
          <TabList>
            <Tab>Title 1</Tab>
            <Tab>Title 2</Tab>
            <Tab>Title 1</Tab>
            <Tab>Inducts for last Hours</Tab>
          </TabList>
          <TabPanel>Mukesh</TabPanel>
          <TabPanel>singh</TabPanel>
          <TabPanel>Mukesh</TabPanel>
          <TabPanel>
              <div className="mainsec">
                <div className="leftpart">Height: </div>
                <div className="rightpart"><input type="text" name="height"/></div>
                <div className="leftpart">Width:</div>
                <div className="rightpart"><input type="text" name="width"/></div>
                <div className="leftpart">Needle Length:</div>
                <div className="rightpart"><input type="text" name="needle"/></div>

                <div className="leftpart">Needle Color:</div>
                <div className="rightpart"><input type="text" name="color"/></div>

                <div className="leftpart">Bar Width:</div>
                <div className="rightpart"><input type="text" name="barwidth"/></div>
                <div className="leftpart">Text Size:</div>
                <div className="rightpart"><input type="text" name="textsize"/></div>
                <div className="leftpart">Sigment:</div>
                <div className="rightpart"><input type="text" name="sigment"/></div>

                <div className="leftpart">Sigment Color:</div>
                <div className="rightpart"><input type="text" name="sigmentColor"/></div>
                <div className="leftpart">Sigment Color:</div>
                <div className="rightpart"><input type="text" name="sigmentColor"/></div>
                <div className="leftpart">Sigment Color:</div>
                <div className="rightpart"><input type="text" name="sigmentColor"/></div>

                <div className="leftpart">Sigment Percentage:</div>
                <div className="rightpart"><input type="text" name="sigmentp"/></div>
                <div className="leftpart">Sigment Percentage:</div>
                <div className="rightpart"><input type="text" name="sigmentp"/></div>
                <div className="clearboth"></div>
                <div className="leftpart">Sigment Percentage:</div>
                <div className="rightpart"><input type="text" name="sigmentp"/></div>
                <div className="clearboth"></div>
                <input type="submit" className="btn-primary subbutton" disabled="" value="Submit"/>
              </div>
              
          </TabPanel>
        </Tabs>
      );
    }
  }
  export default ConfigClass;