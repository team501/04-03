import React, { Component } from 'react';
import './App.css';

// Import module and default styles
import ArcProgressbar from './components/ArcProgressbar';
import 'react-circular-progressbar/dist/styles.css';

// Import custom examples
import SegmentedArcProgressbar from './components/SegmentedArcProgressbar';

class App extends Component {
  
  render() {
    const percentage = 90;

    return (
      <div className="App">
        <div style={{ width: '200px', height: '150px' }}>
          <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
        </div>
      </div>
    );
  }
}

export default App;
