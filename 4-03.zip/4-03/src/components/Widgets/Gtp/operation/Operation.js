import React, { Component } from 'react';



import Pbar from './Pbar.js';
import ArcProgressbar from '../arc/SegmentedArcProgressBar/ArcProgressbar';
import 'react-circular-progressbar/dist/styles.css';

// Import custom examples
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
    render(){
	const percentage = 80;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="operation_bg overall-work-monitor">
							<div className="title">Operation</div>
							<div class="row row-no-margin">
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
								</div>
								<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 leftAlign"> 
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign opHeadertext"> Total
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign center opHeadertext"> Producity
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign opHeadertext"> Bin Status
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign opHeadertext"> Other
								</div>
								
								
							</div>
							
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle"> Packing
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext">(In Units)</div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext">(hh:mm:ss)</div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
									<div style={{ width: '100px', height: '100px' }}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>	
								
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
									<div className="station-status-textblack margin17">25000</div>
									<div className="station-status-activetext">Process rate</div>
									<div className="station-status-textblack">25000</div>
									<div className="station-status-activetext">Process rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">12</div>
									<div className="station-status-activetext">Active</div>
									<div className="station-status-textblack opred">00:00:00</div>
									<div className="station-status-activetext">Dwell Time</div>
								</div>
								
								
							</div>
							<div className="clearboth"></div>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle"> Consolidation
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext">(In Units)</div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext">(hh:mm:ss)</div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
										
								<div style={{ width: '100px', height: '100px' }}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
									<div className="station-status-textblack margin17">25000</div>
									<div className="station-status-activetext">Process rate</div>
									<div className="station-status-textblack">25000</div>
									<div className="station-status-activetext">Process rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">12</div>
									<div className="station-status-activetext">Active</div>
									<div className="station-status-textblack opred">00:00:00</div>
									<div className="station-status-activetext">Dwell Time</div>
								</div>
								
								
							</div>
							<div className="clearboth"></div>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle"> Decanting
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext">(In Units)</div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext">(hh:mm:ss)</div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
										
								<div style={{ width: '100px', height: '100px' }}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
									<div className="station-status-textblack margin17">25000</div>
									<div className="station-status-activetext">Process rate</div>
									<div className="station-status-textblack">25000</div>
									<div className="station-status-activetext">Process rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">12</div>
									<div className="station-status-activetext">Active</div>
									<div className="station-status-textblack opred">00:00:00</div>
									<div className="station-status-activetext">Dwell Time</div>
								</div>
								
								
							</div>
							<div className="clearboth"></div>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle"> Cycle Count
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext">(In Units)</div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext">(hh:mm:ss)</div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
										
								<div style={{ width: '100px', height: '100px' }}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign"> 
									<div className="station-status-textblack margin17">25000</div>
									<div className="station-status-activetext">Process rate</div>
									<div className="station-status-textblack">25000</div>
									<div className="station-status-activetext">Process rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">12</div>
									<div className="station-status-activetext">Active</div>
									<div className="station-status-textblack opred">00:00:00</div>
									<div className="station-status-activetext">Dwell Time</div>
								</div>
								
								
							</div>
							
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
