import React, { Component } from 'react';

//import './landing.css';
import ArcProgressbar from './arc/SegmentedArcProgressBar/ArcProgressbar';
import 'react-circular-progressbar/dist/styles.css';

// Import custom examples
import SegmentedArcProgressbar from './arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
    render(){
	const percentage = 35;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor row-no-margin">
                       <div className="title">Overall Work Monitor</div>
					   <div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 leftAlign">
							<div className="subtitle">Productivity</div>
								<div style={{ width: '120px', height: '120px' }}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>
					   </div>
					   <div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
					   <div className="subtitle">Station status</div>
						   <div>
							   <div className="station-status-text">12</div> 
							   <div className="station-status-activetext">Active</div>
						   </div>
					   <div>
							   <div className="station-status-textred">12</div> 
							   <div className="station-status-activetext">Active</div>
						   </div>
					   <div>
							   <div className="station-status-textblack">12</div> 
							   <div className="station-status-activetext">Active</div>
						   </div>
					   </div>
					   <div className="col-sm-3 col-md-3 col-lg-3 col-xl-3 leftAlign">
					   <div className="subtitle">Bin Status</div>
					   <div>
							   <div className="station-status-textblack">25000</div> 
							   <div className="station-status-activetext">Processed</div>
						   </div>
					   <div>
							   <div className="station-status-textblack">25000</div> 
							   <div className="station-status-activetext">Process rate</div>
						   </div>
					   </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
